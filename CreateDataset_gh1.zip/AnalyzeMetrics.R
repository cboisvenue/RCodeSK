##########################################################
# Project Name: SWE Recursive Spline Analysis (Temporal) #
# Author: Carson Farmer    carson.farmer@gmail.com       #
# File Name: AnalyzeMetricsR                             #
# Objective: Summarise all 13 temporal metrics (mean/var)#
##########################################################

# Set the working directory, this may be needed later
#setwd("/home/cfarmer/working/swe")

cat("start...\n")
# Load library for reading spatial data
library(sp)

# Load library ifultools to compute variance
library(ifultools)

runs <- list("first", "second", "third", "fourth", "fifth", "sixth")

for(run in runs) {
  cat("loading data...\n")
  load(paste(run, "swe_metrics.Rdata", sep = "/"))

  cat("computing metric summaries...")
  # Group one
  NS.mean <- sapply(NS, FUN = mean, USE.NAMES = FALSE, simplify = TRUE)
  NS.vari <- sapply(NS, FUN = variance, USE.NAMES = FALSE, simplify = TRUE)
  SN.mean <- sapply(SN, FUN = mean, USE.NAMES = FALSE, simplify = TRUE)
  SN.vari <- sapply(SN, FUN = variance, USE.NAMES = FALSE, simplify = TRUE)
  XS.mean <- sapply(XS, FUN = mean, USE.NAMES = FALSE, simplify = TRUE)
  XS.vari <- sapply(XS, FUN = variance, USE.NAMES = FALSE, simplify = TRUE)
  SX.mean <- sapply(SX, FUN = mean, USE.NAMES = FALSE, simplify = TRUE)
  SX.vari <- sapply(SX, FUN = variance, USE.NAMES = FALSE, simplify = TRUE)
  TS.mean <- sapply(TS, FUN = mean, USE.NAMES = FALSE, simplify = TRUE)
  TS.vari <- sapply(TS, FUN = variance, USE.NAMES = FALSE, simplify = TRUE)
  RS.mean <- sapply(RS, FUN = mean, USE.NAMES = FALSE, simplify = TRUE)
  RS.vari <- sapply(RS, FUN = variance, USE.NAMES = FALSE, simplify = TRUE)
  cat("group one...")
  
  # Group two
  SA.mean <- sapply(SA, FUN = mean, USE.NAMES = FALSE, simplify = TRUE)
  SA.vari <- sapply(SA, FUN = variance, USE.NAMES = FALSE, simplify = TRUE)
  SM.mean <- sapply(SM, FUN = mean, USE.NAMES = FALSE, simplify = TRUE)
  SM.vari <- sapply(SM, FUN = variance, USE.NAMES = FALSE, simplify = TRUE)
  EM.mean <- sapply(EM, FUN = mean, USE.NAMES = FALSE, simplify = TRUE)
  EM.vari <- sapply(EM, FUN = variance, USE.NAMES = FALSE, simplify = TRUE)
  SL.mean <- sapply(SL, FUN = mean, USE.NAMES = FALSE, simplify = TRUE)
  SL.vari <- sapply(SL, FUN = variance, USE.NAMES = FALSE, simplify = TRUE)
  TP.mean <- sapply(TP, FUN = mean, USE.NAMES = FALSE, simplify = TRUE)
  TP.vari <- sapply(TP, FUN = variance, USE.NAMES = FALSE, simplify = TRUE)
  cat("group two...")
  
  # Group three
  MR.mean <- sapply(MR, FUN = mean, USE.NAMES = FALSE, simplify = TRUE)
  MR.vari <- sapply(MR, FUN = variance, USE.NAMES = FALSE, simplify = TRUE)
  AR.mean <- sapply(AR, FUN = mean, USE.NAMES = FALSE, simplify = TRUE)
  AR.vari <- sapply(AR, FUN = variance, USE.NAMES = FALSE, simplify = TRUE)
  cat("group three...\n")
  cat("creating data.frame of summaries...\n")
  
  # Create data.frame of summary (mean and variance) of metrics
  metrics.summary <- data.frame(NS.mean, NS.vari, SN.mean, SN.vari, XS.mean, XS.vari,
  SX.mean, SX.vari, TS.mean, TS.vari, RS.mean, RS.vari, SA.mean, SA.vari, SM.mean, 
  SM.vari, EM.mean, EM.vari, SL.mean, SL.vari, MR.mean, MR.vari, AR.mean, AR.vari, 
  TP.mean, TP.vari)
  
  cat("loading spatial data...\n")
  load("spatial_data.Rdata")

  if ( run == "first" || run == "third" || run == "fifth" ){
    currxlo <- 1
    currxhi <- 96
    if ( run == "first"){
      currylo <- 1
      curryhi <- 83
    }
      if ( run == "third"){
        currylo <- 84
        curryhi <- 166
    }
      if ( run == "fifth"){
        currylo <- 167
        curryhi <- 249
      }
  }
  else {
    currxlo <- 97
    currxhi <- 192
    if ( run == "second"){
      currylo <- 1
      curryhi <- 83
    }
    if ( run == "fourth"){
      currylo <- 84
      curryhi <- 166
    }
    if ( run == "sixth"){
      currylo <- 167
      curryhi <- 249
    }
  }

  cat("generating subset...\n")
  # Subset the data to our localized study region
  # subset for prairies = [35:124, 25:95]
  spatial.metrics <- spatial.data[currylo:curryhi,currxlo:currxhi]
  spatial.metrics@data <- metrics.summary
  
  # Remove extra variables...
  rm(spatial.data, NS.mean, NS.vari, SN.mean, SN.vari, XS.mean, XS.vari,
  SX.mean, SX.vari, TS.mean, TS.vari, RS.mean, RS.vari, SA.mean, SA.vari, SM.mean, 
  SM.vari, EM.mean, EM.vari, SL.mean, SL.vari, MR.mean, MR.vari, AR.mean, AR.vari, 
  TP.mean, TP.vari )
  gc()
  gc()
  
  # Save data to file
  cat("saving data to file...\n")
  save(spatial.metrics, file = paste(run, "spatial_metrics.Rdata", 
  sep = "/"))
  
  # Save data to file
  cat("creating output GTIFF file...\n")
  require(rgdal)
  writeGDAL( dataset = spatial.metrics, fname = paste(run, "spatial",
  "metrics.tiff", sep="_"), drivername = "GTiff", type = "Float32" )
} # next run (subset)
cat("done!")
