 ##########################################################
  # Project Name: SWE Recursive Spline Analysis (Temporal) #
  # Author: Geordie Hoabart    ghobart@nrcan.gc.ca         #
  # File Name: Magic Numbers.R                             #
  # Objective: A central repository for all global variables#
  # Modifications                                          #
  ##########################################################

  YEAR_DAYS = 365
  BASE_YEAR = 1999
  END_YEAR = 2006
  SNOW_FREE_DAY = 265
  TOTAL_DAYS = (END_YEAR - BASE_YEAR  )*YEAR_DAYS + SNOW_FREE_DAY
  BASE_DIR =  "F:/wkspace/DailySWE"
  SCR_DATA_DIR  = "F:/wkspace/DailySWE/AllDays"

save(  YEAR_DAYS, BASE_YEAR, END_YEAR, SNOW_FREE_DAY,  TOTAL_DAYS, BASE_DIR, SCR_DATA_DIR,file = "F:/wkspace/DailySWE/magic_numbers.Rdata")
