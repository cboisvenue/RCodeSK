  ##########################################################
  # Project Name: SWE Recursive Spline Analysis (Temporal) #
  # Author: Carson Farmer    carson.farmer@gmail.com       #
  # File Name: CreateDataset.R                             #
  # Objective: Combine all available years of SWE data     # 
  # Modifications                                          #
  ##########################################################
  
  #Set the working directory, this may be needed later
  #setwd("/home/cfarmer/working/swe")
  rm(list=ls()) 
  cat("start...\n")
  #Load library for reading spatial data
  library(sp)
  # load global variables
  load(file = "F:/wkspace/DailySWE/magic_numbers.Rdata")
 runs <- list("first", "second", "third", "fourth", "fifth", "sixth")
 # runs <- list("fifth")
  
  for(run in runs) {
      #The following produces a file called Dynamic, which contains the first year of SWE data
      cat("loading initial data...\n")
      load("F:/wkspace/DailySWE/AllDays1999.Rdata")
    
      if ( run == "first" || run == "third" || run == "fifth" ){
          currxlo <- 1
          currxhi <- 96
          if ( run == "first"){
              currylo <- 1
              curryhi <- 83
          }
          if ( run == "third"){
              currylo <- 84
              curryhi <- 166
          }
          if ( run == "fifth"){
              currylo <- 167
              curryhi <- 249
          }
      }
      else {
          currxlo <- 97
          currxhi <- 192
          if ( run == "second"){
              currylo <- 1
              curryhi <- 83
          }
          if ( run == "fourth"){
              currylo <- 84
              curryhi <- 166
          }
          if ( run == "sixth"){
              currylo <- 167
              curryhi <- 249
          }
      }
    
    
    
      cat("generating subset...\n")
      # Subset the data to our localized study region
      # subset for prairies = [35:124, 25:95]
      temp <- Dynamic[currylo:curryhi,currxlo:currxhi]
    
      #Create sequence to run through all remaining years
      years <- seq(BASE_YEAR+1, END_YEAR) 
    
      cat("combining datasets...\n")
      #Now, cbind the datasets for all years from 1989 - 2006 (inclusive) to current year
      for(i in years) {
          #cat("combining values from", i, "\r")
          #flush.console()
          load(paste(SCR_DATA_DIR, 
          i, ".Rdata", sep = ""))
          temp <- cbind(temp, Dynamic[currylo:curryhi,currxlo:currxhi])
          # subset for praries [35:124, 25:95]
          rm(Dynamic)
          gc()
      }
      cat("\n")
    
      cat("extracting data only...\n")
      #Grab the SWE data for the entire (subsetted) dataset
      data <- temp@data
    
      #Remove temp now to conserve space
       #save(temp, file = paste(run, "temp.Rdata", sep = "/"))
      tmp_file =paste(BASE_DIR,paste(run, "temp.Rdata", sep = "/"), sep = "/") 
      save(temp, file = tmp_file)
      rm(temp)
      gc()
      memory.limit(size=2000)

      cat("transforming data...\n")
      #Transform the data, so that rows become columns
      data.trans <- t(data)
    
      #Remove data to save space
      save(data, file =  tmp_file )
      rm(data)
      gc()
      memory.limit(size=2000)
      
      cat("making all zero values in data.trans == NA...\n")
      #Make all zero values in data.trans = NA
      data.trans[data.trans == 0] <- NA
    
      #Divide all values by 10 (adjust for incorrect decimal placement in original data)
      data.trans / 10
    
      cat("adjusting for erroneous data...\n")
      #If a cell has an erroneous value, make it equal to zero
      data.trans[data.trans >= -7] <- 0.00
      
      
      tmp_file =paste(BASE_DIR,paste(run, "data_trans.Rdata", sep = "/"), sep = "/") 
      
      #Save the transformed data
      save(data.trans, file = tmp_file)
    
      cat("creating a time variable...\n")
      #Create a time variable for prediction later on
      predict.x <- seq(1,dim(data.trans)[1]) / YEAR_DAYS + BASE_YEAR
    
      #Save the time variable for later
      pred_file=  paste(BASE_DIR,paste(run, "predict_x.Rdata", sep = "/"), sep = "/")
      save(predict.x, file =pred_file )
      rm(predict.x, data.trans)
      gc()
      gc()
  
  }
  cat("...end\n")
  
  
