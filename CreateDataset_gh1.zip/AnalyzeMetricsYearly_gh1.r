##########################################################
# Project Name: SWE Recursive Spline Analysis (Temporal) #
# Author: Carson Farmer    carson.farmer@gmail.com       #
# File Name: AnalyzeMetricsR                             #
# Objective: Summarise all 13 temporal metrics (mean/var)#
##########################################################

# Set the working directory, this may be needed later
#setwd("/home/cfarmer/working/swe")
load(file = "F:/wkspace/DailySWE/magic_numbers.Rdata")

cat("start...\n")
# Load library for reading spatial data
library(sp)

# Load library ifultools to compute variance
library(ifultools)

runs <- list("first", "second", "third", "fourth", "fifth", "sixth")
#runs <- list( "fifth")

for(run in runs) {
  cat("loading data...\n")
  met_file =paste(BASE_DIR,paste(run, "swe_metrics.Rdata", sep = "/"), sep = "/") 
  load(met_file)

  cat("loading spatial data...\n")
  load("T:/biospace/swe/code/swe_r_code/spatial_data.Rdata")

   if ( run == "first" || run == "third" || run == "fifth" ){
    currxlo <- 1
    currxhi <- 96
    if ( run == "first"){
      currylo <- 1
      curryhi <- 83
    }
      if ( run == "third"){
        currylo <- 84
        curryhi <- 166
    }
      if ( run == "fifth"){
        currylo <- 167
        curryhi <- 249
      }
  }
  else {
    currxlo <- 97
    currxhi <- 192
    if ( run == "second"){
      currylo <- 1
      curryhi <- 83
    }
    if ( run == "fourth"){
      currylo <- 84
      curryhi <- 166
    }
    if ( run == "sixth"){
      currylo <- 167
      curryhi <- 249
    }
  }
  

  require(rgdal)

  spatial.metrics <- spatial.data[currylo:curryhi,currxlo:currxhi]
  
  # do NS
 # tempNS <- t(as.data.frame(NS))
#  NSMean.summary <- data.frame(t(as.data.frame(NS)))                                                             
  spatial.metrics@data <- data.frame(t(as.data.frame(NS)))
  tiff_file =fname = paste(BASE_DIR, "MinSWE", paste(run, "MinSWE.tiff", sep="_"),  sep = "/") 
  writeGDAL( dataset = spatial.metrics, fname = tiff_file , drivername = "GTiff", type = "Float32"  )
  
  # do  SN
  spatial.metrics@data <- data.frame(t(as.data.frame(SN)))
  tiff_file =fname = paste(BASE_DIR, "TofMinSWE", paste(run, "TofMinSWE.tiff", sep="_"),  sep = "/") 
  writeGDAL( dataset = spatial.metrics, fname = tiff_file , drivername = "GTiff", type = "Float32" )
  
  # do  XS
  spatial.metrics@data <- data.frame(t(as.data.frame(XS)))
  tiff_file =fname = paste(BASE_DIR, "MaxSWE", paste(run, "MaxSWE.tiff", sep="_"),  sep = "/") 
  writeGDAL( dataset = spatial.metrics, fname = tiff_file , drivername = "GTiff", type = "Float32" )
  
  # do  SX
  spatial.metrics@data <- data.frame(t(as.data.frame(SX)))
  tiff_file =fname = paste(BASE_DIR, "TofMaxSWE", paste(run, "TofMaxSWE.tiff", sep="_"),  sep = "/") 
  writeGDAL( dataset = spatial.metrics, fname = tiff_file , drivername = "GTiff", type = "Float32" )
  
# do  TS
  spatial.metrics@data <- data.frame(t(as.data.frame(TS)))
  tiff_file =fname = paste(BASE_DIR, "TotSWE", paste(run, "TotSWE.tiff", sep="_"),  sep = "/") 
  writeGDAL( dataset = spatial.metrics, fname = tiff_file , drivername = "GTiff", type = "Float32" )
    
# do  RS
  spatial.metrics@data <- data.frame(t(as.data.frame(RS)))
  tiff_file =fname = paste(BASE_DIR, "RangeSWE", paste(run, "RangeSWE.tiff", sep="_"),  sep = "/") 
  writeGDAL( dataset = spatial.metrics, fname = tiff_file , drivername = "GTiff", type = "Float32" )
  
# do  SA
  spatial.metrics@data <- data.frame(t(as.data.frame(SA)))
  tiff_file =fname = paste(BASE_DIR, "StartSWE", paste(run, "StartSWE.tiff", sep="_"),  sep = "/") 
  writeGDAL( dataset = spatial.metrics, fname = tiff_file , drivername = "GTiff", type = "Float32" )

# do  SM
  spatial.metrics@data <- data.frame(t(as.data.frame(SM)))
  tiff_file =fname = paste(BASE_DIR, "StartMelt", paste(run, "StartMelt.tiff", sep="_"),  sep = "/") 
  writeGDAL( dataset = spatial.metrics, fname = tiff_file , drivername = "GTiff", type = "Float32" )

# do  EM
  spatial.metrics@data <- data.frame(t(as.data.frame(EM)))
  tiff_file =fname = paste(BASE_DIR, "EndMelt", paste(run, "EndMelt.tiff", sep="_"),  sep = "/") 
  writeGDAL( dataset = spatial.metrics, fname = tiff_file , drivername = "GTiff", type = "Float32" )

# do  SL
  spatial.metrics@data <- data.frame(t(as.data.frame(SL)))
  tiff_file =fname = paste(BASE_DIR, "LengthSWE", paste(run, "LengthSWE.tiff", sep="_"),  sep = "/") 
  writeGDAL( dataset = spatial.metrics, fname = tiff_file , drivername = "GTiff", type = "Float32" )

# do  MR
  spatial.metrics@data <- data.frame(t(as.data.frame(MR)))
  tiff_file =fname = paste(BASE_DIR, "MeltRate", paste(run, "MeltRate.tiff", sep="_"),  sep = "/") 
  writeGDAL( dataset = spatial.metrics, fname = tiff_file , drivername = "GTiff", type = "Float32" )

# do  AR
  spatial.metrics@data <- data.frame(t(as.data.frame(AR)))
  tiff_file =fname = paste(BASE_DIR, "AccRate", paste(run, "AccRate.tiff", sep="_"),  sep = "/") 
  writeGDAL( dataset = spatial.metrics, fname = tiff_file , drivername = "GTiff", type = "Float32" )

# do  TP
  spatial.metrics@data <- data.frame(t(as.data.frame(TP)))
  tiff_file =fname = paste(BASE_DIR, "Period", paste(run, "Period.tiff", sep="_"),  sep = "/") 
  writeGDAL( dataset = spatial.metrics, fname = tiff_file , drivername = "GTiff", type = "Float32" )

   # Remove extra variables...
  rm(spatial.data, NS, SN, XS,  SX, TS.mean, TS, RS, SA, SM, EM, SL, MR, AR,  TP )
  gc()
  gc()
  
} # next run (subset)
cat("done!")
