##########################################################
#Project Name: SWE Recursive Spline Analysis (Temporal)
#Author: Carson Farmer    carson.farmer@gmail.com
#File Name: CreateMetrics.R
#Objective: Derive SWE temporal metrics from SWE spline curve
##########################################################

# Set the working directory, this may be needed later
# setwd("/home/cfarmer/working/swe")
load(file = "F:/wkspace/DailySWE/magic_numbers.Rdata")

runs <- list("first", "second", "third", "fourth", "fifth", "sixth")

for(run in runs) {

  cat("Loading data...\n")
  spl_file =paste(BASE_DIR,paste(run, "spline_values.Rdata", sep = "/"), sep = "/") 
  dd1_file =paste(BASE_DIR,paste(run, "data_deriv1.Rdata", sep = "/"), sep = "/") 
  dd2_file =paste(BASE_DIR,paste(run, "data_deriv2.Rdata", sep = "/"), sep = "/") 
           
  load(spl_file)
  load(dd1_file)                                    
  load(dd2_file)

  #Create the vectors for all the temporal metrics
  cat("Generating metric vectors...\n")
  
  cat("group one \n")
  # Group one
  NS <- list()
  SN <- list()
  XS <- list()
  SX <- list()
  TS <- list()
  RS <- list()
  # Group two
  cat("group two \n")
  SA <- list()
  SM <- list()
  EM <- list()
  SL <- list()
  TP <- list()
  # Group three
  cat("group 3 \n")
  MR <- list()
  AR <- list()

  size <- seq(1, length(spline.values))
  cat("here ... \n")
  #Load library that allows us to use a discrete moving window aggregation of the derivatives
  require(ifultools)
  cat("here ... 2 \n")
  #This will compute the temporal metrics on the initial spline (Group one)
  for(i in size) {
    #cat(paste(i,"here ... \n", sep="_"))
    #cat(paste("Computing metrics on spline number ", i, "\r","\n",sep=""))
    if(is.na(spline.values[[i]])) {
      NS[[i]] <- NA
      SN[[i]] <- NA
      XS[[i]] <- NA
      SX[[i]] <- NA
      TS[[i]] <- NA
      RS[[i]] <- NA
    } else {
      NS[[i]] <- aggregateData(spline.values[[i]][SNOW_FREE_DAY:TOTAL_DAYS], by = YEAR_DAYS, FUN = max, moving = YEAR_DAYS)
      SN[[i]] <- aggregateData(spline.values[[i]][SNOW_FREE_DAY:TOTAL_DAYS], by = YEAR_DAYS, FUN = which.max, moving = YEAR_DAYS)
      XS[[i]] <- aggregateData(spline.values[[i]][SNOW_FREE_DAY:TOTAL_DAYS], by = YEAR_DAYS, FUN = min, moving = YEAR_DAYS)
      SX[[i]] <- aggregateData(spline.values[[i]][SNOW_FREE_DAY:TOTAL_DAYS], by = YEAR_DAYS, FUN = which.min, moving = YEAR_DAYS)
      TS[[i]] <- aggregateData(spline.values[[i]][SNOW_FREE_DAY:TOTAL_DAYS], by = YEAR_DAYS, FUN = sum, moving = YEAR_DAYS)
      RS[[i]] <- NS[[i]] - XS[[i]]
      
               }
        }
  cat("\n")

  #Load pastecs library for doing the start of season analysis
  require(pastecs)

  #This will compute the temporal metrics on the 2nd derivative
  for(i in size) { 
    #cat("Computing metrics on 2nd derivative number ", i, "\r")
    #flush.console()
    if(is.na(data.deriv2[[i]])) {
      SA[[i]] <-  NA
      SM[[i]] <-  NA                                                                                                                                         
      EM[[i]] <-  NA
      SL[[i]] <-  NA
      TP[[i]] <-  NA
    } else {
      SA[[i]] <- aggregateData(data.deriv2[[i]][SNOW_FREE_DAY:TOTAL_DAYS], by = YEAR_DAYS, FUN = function(a) which.max(extract(turnpoints(a), no.tp = 0, peak = 0, pit = 1)), moving = YEAR_DAYS)
      SM[[i]] <- aggregateData(data.deriv2[[i]][SNOW_FREE_DAY:TOTAL_DAYS], by = YEAR_DAYS, FUN = which.min, moving = YEAR_DAYS)
      EM[[i]] <- aggregateData(data.deriv2[[i]][SNOW_FREE_DAY:TOTAL_DAYS], by = YEAR_DAYS, FUN = which.max, moving = YEAR_DAYS)
      SL[[i]] <- EM[[i]] - SA[[i]]
      TP[[i]] <- YEAR_DAYS - SL[[i]]
      }
        }
  cat("2nd derivative done\n")

  #This will compute the temporal metrics on the 1st derivative
  for(i in size) {
    #cat("Computing metrics on 1st derivative number ", i, "\r")
    #flush.console()
    if(is.na(data.deriv1[[i]])) {
      MR[[i]] <-  NA
      AR[[i]] <-  NA
    } else {
      MR[[i]] <- aggregateData(data.deriv1[[i]][SNOW_FREE_DAY:TOTAL_DAYS], by = YEAR_DAYS, FUN = max, moving = YEAR_DAYS)
      AR[[i]] <- aggregateData(data.deriv1[[i]][SNOW_FREE_DAY:TOTAL_DAYS], by = YEAR_DAYS, FUN = min, moving = YEAR_DAYS)
      
      #AR[[i]] <- aggregateData(ifelse(data.deriv1[[i]] < 0, data.deriv1[[i]], NA)[SNOW_FREE_DAY:TOTAL_DAYS], by = YEAR_DAYS, FUN = function(a) mean(a, na.rm = T), moving = YEAR_DAYS)
      }
        }
  cat("Computed metrics\n")

  #Save all these metrics to file
  cat("\nSaving SWE metrics to file...\n")
  metrics_file =paste(BASE_DIR,paste(run, "swe_metrics.Rdata", sep = "/"), sep = "/") 
 
  save(NS, SN, XS, SX, TS, RS, SA, SM, EM, SL, MR, AR, TP,  file = metrics_file)

}

