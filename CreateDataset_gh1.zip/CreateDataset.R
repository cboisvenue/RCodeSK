##########################################################
# Project Name: SWE Recursive Spline Analysis (Temporal) #
# Author: Carson Farmer    carson.farmer@gmail.com       #
# File Name: CreateDataset.R                             #
# Objective: Combine all available years of SWE data     #
##########################################################

#Set the working directory, this may be needed later
#setwd("/home/cfarmer/working/swe")

cat("start...\n")
#Load library for reading spatial data
library(sp)
load(file = "F:/wkspace/DailySWE/magic_numbers.Rdata")

runs <- list("first", "second", "third", "fourth", "fifth", "sixth")

for(run in runs) {
  #The following produces a file called Dynamic, which contains the first year of SWE data
  cat("loading initial data...\n")
  load("/media/Biggie/July302008/CDrive/working/pub/DATASETS/brightness-temperatures/easegrid/ssmi/north/AllValues/AllDays1988.Rdata")

  if ( run == "first" || run == "third" || run == "fifth" ){
    currxlo <- 1
    currxhi <- 96
    if ( run == "first"){
      currylo <- 1
      curryhi <- 83
    }
      if ( run == "third"){
        currylo <- 84
        curryhi <- 166
    }
      if ( run == "fifth"){
        currylo <- 167
        curryhi <- 249
      }
  }
  else {
    currxlo <- 97
    currxhi <- 192
    if ( run == "second"){
      currylo <- 1
      curryhi <- 83
    }
    if ( run == "fourth"){
      currylo <- 84
      curryhi <- 166
    }
    if ( run == "sixth"){
      currylo <- 167
      curryhi <- 249
    }
  }



  cat("generating subset...\n")
  # Subset the data to our localized study region
  # subset for prairies = [35:124, 25:95]
  temp <- sweByYear[currylo:curryhi,currxlo:currxhi]

  #Create sequence to run through all remaining years
  years <- seq(1989, 2006)

  cat("combining datasets...\n")
  #Now, cbind the datasets for all years from 1989 - 2006 (inclusive) to current year
  for(i in years) {
    cat("combining values from", i, "\r")
    flush.console()
    load(paste("/media/Biggie/July302008/CDrive/working/pub/DATASETS/brightness-temperatures/easegrid/ssmi/north/AllValues/AllDays", 
    i, ".Rdata", sep = ""))
    temp <- cbind(temp, Dynamic[currylo:curryhi,currxlo:currxhi])
    # subset for praries [35:124, 25:95]
    rm(sweByYear)
    gc()
  }
  cat("\n")

  cat("extracting data only...\n")
  #Grab the SWE data for the entire (subsetted) dataset
  data <- temp@data

  #Remove temp now to conserve space
  save(temp, file = paste(run, "temp.Rdata", sep = "/"))
  rm(temp)
  gc()

  cat("transforming data...\n")
  #Transform the data, so that rows become columns
  data.trans <- t(data)

  #Remove data to save space
  save(data, file = paste(run, "data.Rdata", sep = "/"))
  rm(data)
  gc()

  cat("making all zero values in data.trans == NA...\n")
  #Make all zero values in data.trans = NA
  data.trans[data.trans == 0] <- NA

  #Divide all values by 10 (adjust for incorrect decimal placement in original data)
  data.trans / 10

  cat("adjusting for erroneous data...\n")
  #If a cell has an erroneous value, make it equal to zero
  data.trans[data.trans >= -7] <- 0.00

  #Save the transformed data
  save(data.trans, file = paste(run, "data_trans.Rdata", sep = "/"))

  cat("creating a time variable...\n")
  #Create a time variable for prediction later on
  predict.x <- seq(1,dim(data.trans)[1]) / 365 + 1988

  #Save the time variable for later
  save(predict.x, file = paste(run, "predict_x.Rdata", sep = "/"))
  rm(predict.x, data.trans)
  gc()
  gc()

}
cat("...end\n")


