#LOCATION = 96*59+64
LOCATION = 27000
setwd("D:/globsnow/DailySWE/first")
load("spline_values.Rdata")
theset=spline.values[[LOCATION]]
x=1:length(theset)
plot(x,theset)
win.graph()
load("data_trans.Rdata")
goodData = data.trans[!is.na(data.trans[,LOCATION]),LOCATION]
xa=1:length(goodData)
plot(xa,goodData)

rng = seq(1:5)

basex <- seq(1,TOTAL_DAYS+20) / YEAR_DAYS + BASE_YEAR

for ( i in rng){                                                      
  LOCATION = 27000 + i*100
  theset=spline.values[[LOCATION]]
  x=1:length(theset)
  if (length(x) > 100) {
        indx = as.character(LOCATION)
        if (! length(x)== 0){
          plot(basex,theset, main = paste("For pixel ",indx))
       }
     win.graph()
  }

}



years = seq(1982,2008,1)
 
  for (year in years)  {
      print(paste("The year is ",year))
      idx_Years=agrep(gsub(" ","",paste(as.character(year),"*")), fncs[,YYYYMMDD ])
      data2 = fncs[idx_Years,]
      for (cnt in 1:365 ){
          jd = data2[1,1]- 1 +cnt 
          z = which(data2 == jd,arr.ind =TRUE)
          if (! (is.na(z[1])))  {
             filename = data2[z[1],2]
           
             nc <- open.ncdf( filename, write=FALSE, readunlim=TRUE, verbose=FALSE )
             sweByYear[,,cnt] = get.var.ncdf( nc, "SWE" )[155:346,238:488]* mask
             close.ncdf(nc)
          } else {                                                                                                 
              if ( cnt > 185 && cnt < 273 ){
              sweByYear[,,cnt] = summerData * mask
              }
          }            
       }  

load(file = "D:/globsnow/rcode/magic_numbers.Rdata")
setwd("D:/globsnow/first_run/")
load("spline_values.Rdata")

orig_spline =  spline.values

setwd("D:/globsnow/DailySWE/")
load("spline_values.Rdata")
load("data_trans.Rdata")
adj_spline =  spline.values

i = 37509
theset=orig_spline[[i]]
TOTAL_DAYS = (END_YEAR - BASE_YEAR  )*YEAR_DAYS 
basex <- seq(1,TOTAL_DAYS) / YEAR_DAYS + BASE_YEAR                        
len = 1:length(theset)
y = theset[1:9855]  
indx = as.character(i)
#y_lim = max(max(y),max(ya) 
goodData = data.trans[,i]

ya = goodData[1:9855] 
#ya= goodData
y_lim_max =  ceiling(max(max(y, na.rm = TRUE),max(ya , na.rm = TRUE)))
y_lim = c(-100,200)    
#plot(basex,y, main = paste("For pixel ",indx),type = "l", col="red", xlim = max(basex) ,ylim = y_lim)
#par(new=TRUE)
#plot(basex,ya, main = paste("For pixel ",indx), xlim = max(basex) , ylim= y_lim)
win.graph()
par(new=TRUE)
plot(basex,y, main = paste("For pixel ",indx),type = "l", col="red",  ylim = y_lim,xlim = c(1982,2008) )
par(new=TRUE)
plot(basex,ya, main = paste("For pixel ",indx),  ylim= y_lim, xlim = c(1982,2008) )
grid( nx = 28 ,col = "lightgray", lty = "dotted",      lwd = par("lwd"), equilogs = TRUE)

theset=adj_spline[[i]]
y = theset[1:9855]
par(new=TRUE)  
plot(basex,y, main = paste("For pixel ",indx),type = "l", col="blue",  ylim = y_lim,xlim = c(1982,2008) )



y1 = data.deriv1 [[i]]  [1:9855] 
y2 = data.deriv2 [[i]]  [1:9855] 
win.graph()
plot(basex,y1, main = paste("1st Derivative",indx),xlim = c(1982,2008) )
grid( nx = 28 ,col = "lightgray", lty = "dotted",      lwd = par("lwd"), equilogs = TRUE)
win.graph()
plot(basex,y2, main = paste("2st Derivative",indx),xlim = c(1982,2008) )
grid( nx = 28 ,col = "lightgray", lty = "dotted",      lwd = par("lwd"), equilogs = TRUE)

for (i in k ){

          theset=orig_spline[[i]]
          TOTAL_DAYS = (END_YEAR - BASE_YEAR  )*YEAR_DAYS

          basex <- seq(1,TOTAL_DAYS) / YEAR_DAYS + BASE_YEAR
          len = 1:length(theset)
          y = theset[1:9855]

          indx = as.character(i)


          goodData = data.trans[,i]
          ya = goodData[1:9855]

          y_lim_max =  ceiling(max(max(y, na.rm = TRUE),max(ya , na.rm = TRUE)))
          y_lim = c(-100,y_lim_max)

          win.graph()

          plot(basex,y, main = paste("For pixel ",indx),type = "l", col="red",  ylim = y_lim,xlim = c(1981,2009) )
          par(new=TRUE)
          plot(basex,ya, main = paste("For pixel ",indx), col="green", ylim= y_lim, xlim = c(1981,2009) )
          grid( nx = 30 ,col = "lightgray", lty = "dotted", lwd = par("lwd"), equilogs = TRUE)
          
          y1 =EM[[i]][1:9855]
          y2 = SM[[i]][1:9855]

          abline( v = y1, col = "blue", untf = FALSE  )
          abline( v = y2,  col = "brown", untf = FALSE)


 }
 