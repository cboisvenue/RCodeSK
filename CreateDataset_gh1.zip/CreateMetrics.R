##########################################################
#Project Name: SWE Recursive Spline Analysis (Temporal)
#Author: Carson Farmer    carson.farmer@gmail.com
#File Name: CreateMetrics.R
#Objective: Derive SWE temporal metrics from SWE spline curve
##########################################################

# Set the working directory, this may be needed later
# setwd("/home/cfarmer/working/swe")

runs <- list("first", "second", "third", "fourth", "fifth", "sixth")

for(run in runs) {

  cat("Loading data...\n")
  spl_file =paste("F:/wkspace/DailySWE",paste(run, "spline_values.Rdata", sep = "/"), sep = "/") 
  dd1_file =paste("F:/wkspace/DailySWE",paste(run, "data_deriv1.Rdata", sep = "/"), sep = "/") 
  dd2_file =paste("F:/wkspace/DailySWE",paste(run, "data_deriv2.Rdata", sep = "/"), sep = "/") 
           
  load(paste(run, "spline_values.Rdata", sep = "/"))
  load(paste(run, "data_deriv1.Rdata", sep = "/"))
  load(paste(run, "data_deriv2.Rdata", sep = "/"))

  #Create the vectors for all the temporal metrics
  cat("Generating metric vectors...\n")
  
  # Group one
  NS <- list()
  SN <- list()
  XS <- list()
  SX <- list()
  TS <- list()
  RS <- list()
  # Group two
  SA <- list()
  SM <- list()
  EM <- list()
  SL <- list()
  TP <- list()
  # Group three
  MR <- list()
  AR <- list()

  size <- seq(1, length(spline.values))

  #Load library that allows us to use a discrete moving window aggregation of the derivatives
  require(ifultools)

  #This will compute the temporal metrics on the initial spline (Group one)
  for(i in size) {
    cat("Computing metrics on spline number ", i, "\r")
    flush.console()
    if(is.na(spline.values[[i]])) {
      NS[[i]] <- NA
      SN[[i]] <- NA
      XS[[i]] <- NA
      SX[[i]] <- NA
      TS[[i]] <- NA
      RS[[i]] <- NA
    } else {
      NS[[i]] <- aggregateData(spline.values[[i]][265:6090], by = 365, FUN = max, moving = 365)
      SN[[i]] <- aggregateData(spline.values[[i]][265:6090], by = 365, FUN = which.max, moving = 365)
      XS[[i]] <- aggregateData(spline.values[[i]][265:6090], by = 365, FUN = min, moving = 365)
      SX[[i]] <- aggregateData(spline.values[[i]][265:6090], by = 365, FUN = which.min, moving = 365)
      TS[[i]] <- aggregateData(spline.values[[i]][265:6090], by = 365, FUN = sum, moving = 365)
      RS[[i]] <- NS[[i]] - XS[[i]]
               }
        }
  cat("\n")

  #Load pastecs library for doing the start of season analysis
  require(pastecs)

  #This will compute the temporal metrics on the 2nd derivative
  for(i in size) {
    cat("Computing metrics on 2nd derivative number ", i, "\r")
    flush.console()
    if(is.na(data.deriv2[[i]])) {
      SA[[i]] <-  NA
      SM[[i]] <-  NA
      EM[[i]] <-  NA
      SL[[i]] <-  NA
      TP[[i]] <-  NA
    } else {
      SA[[i]] <- aggregateData(data.deriv2[[i]][265:6090], by = 365, FUN = function(a) which.max(extract(turnpoints(a), no.tp = 0, peak = 0, pit = 1)), moving = 365)
      SM[[i]] <- aggregateData(data.deriv2[[i]][265:6090], by = 365, FUN = which.min, moving = 365)
      EM[[i]] <- aggregateData(data.deriv2[[i]][265:6090], by = 365, FUN = which.max, moving = 365)
      SL[[i]] <- EM[[i]] - SA[[i]]
      TP[[i]] <- 365 - SL[[i]]
      }
        }
  cat("\n")

  #This will compute the temporal metrics on the 1st derivative
  for(i in size) {
    cat("Computing metrics on 1st derivative number ", i, "\r")
    flush.console()
    if(is.na(data.deriv1[[i]])) {
      MR[[i]] <-  NA
      AR[[i]] <-  NA
    } else {
      MR[[i]] <- aggregateData(data.deriv1[[i]][265:6090], by = 365, FUN = max, moving = 365)
      AR[[i]] <- aggregateData(ifelse(data.deriv1[[i]] < 0, data.deriv1[[i]], NA)[265:6090], by = 365, FUN = function(a) mean(a, na.rm = T), moving = 365)
      }
        }
  cat("\n")

  #Save all these metrics to file
  cat("\nSaving SWE metrics to file...\n")
  save(NS, SN, XS, SX, TS, RS, SA, SM, EM, SL, MR, AR, TP, 
  file = paste(run, "swe_metrics.Rdata", sep = "/"))

}

