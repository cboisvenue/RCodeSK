#LOCATION = 96*59+64

setwd("F:/wkspace/DailySWE/first")
load("D:/globsnow/DailySWE/first/spline_values.Rdata")
load("D:/globsnow/DailySWE/first/data_trans.Rdata")
LOCATION = 27000
theset=spline.values[[LOCATION]]
x=1:length(theset)

win.graph()
lengyt

for 