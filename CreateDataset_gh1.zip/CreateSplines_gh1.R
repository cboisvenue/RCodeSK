##########################################################
#Project Name: SWE Recursive Spline Analysis (Temporal)
#Author: Carson Farmer    carson.farmer@gmail.com
#File Name: CreateSplines.R
#Objective: Perform recursive spline algorithm
##########################################################

# Set the working directory, this may be needed later
# setwd("/home/cfarmer/working/swe")
#load(file= "T:/biospace/swe/code/swe_r_code/MagicNumbers.r")
runs <- list("first","fourth", "fifth", "sixth")
#runs <- list("first", "second", "third", "fourth", "fifth", "sixth")
#runs <- list(  "fifth")

for(run in runs) {
memory.limit(size=2000)
  cat(paste("Starting", run, "run", delim=" "))
  # The following produces a file called data.trans, which contains all data values
  load ("F:/wkspace/DailySWE/magic_numbers.Rdata")
  dt_file =paste(BASE_DIR,paste(run, "data_trans.Rdata", sep = "/"), sep = "/") 
 
  load(dt_file)
  
  basex <- seq(1,TOTAL_DAYS+20) / YEAR_DAYS + BASE_YEAR

  # Spline Algorithm
  cat("Creating recursive function...\n")
  recur <- function(colnum) {
    y <- data.trans[,colnum]
    x <- ifelse(is.na(y), NA, basex)
    x <- na.omit(x)
    y <- na.omit(y)
    gc()
    if(length(x) <= 0) {
      return(NA)
    } else {
        initial <- y - predict(smooth.spline(x, y), x, 0)$y
        weights <- ifelse(initial < -15, 0, exp((sign(initial)*-1) - abs(initial/5)^2))
        return(smooth.spline(x, y, spar = 0.35, w = weights))
      } 
  }

  #This will create an 'empty' vector that we will put our splines into
  sp_len <- seq(1, dim(data.trans)[2]) #I changed this to 50
  data.splines <- list()

  #This will compute the splines and put them into data.splines
  for(i in sp_len) {
    #cat("Computing spline number ", i, "\r")
    #flush.console()
    data.splines[[i]] <- recur(i)
  }
  cat("Computed splines")
  cat("\n")

  #Remove any extraneous variables
  rm(data.trans, i, recur)
  #Garbage cleanup
  gc()
  gc()

  cat("Saving splines to file...\n")
  #and save the results for later
  dspl_file =paste(BASE_DIR,paste(run, "data_splines.Rdata", sep = "/"), sep = "/") 
 
  save(data.splines, file = dspl_file)

  #Create a function to calcualte values based on a spline...
  getValues <- function(input, degree, place) {
    if(is.na(input)) {
      return(NA)
    }
    else {
      return(predict(input, basex, degree)$y)
    }
  }

  #These are the 
  spline.values <- list()
  data.deriv1 <- list()
  data.deriv2 <- list()

  #This will compute the values, and first and second derivative
  for(i in sp_len) {
  
    #cat("Computing derivatives on spline number ", i, "\r")
    #flush.console()
    spline.values[[i]] <- getValues(data.splines[[i]], 0, i)
    data.deriv1[[i]] <- getValues(data.splines[[i]], 1, i)
    
    data.deriv2[[i]] <- getValues(data.splines[[i]], 2, i)
  }
  cat("done computing values\n")

  #...and save the results in case we need them later...
  cat("Saving values and derivatives to file...\n")
  spl_file =paste(BASE_DIR,paste(run, "spline_values.Rdata", sep = "/"), sep = "/") 
  dd1_file =paste(BASE_DIR,paste(run, "data_deriv1.Rdata", sep = "/"), sep = "/") 
  dd2_file =paste(BASE_DIR,paste(run, "data_deriv2.Rdata", sep = "/"), sep = "/") 

  save(spline.values, file = spl_file)
  save(data.deriv1, file = dd1_file)
  save(data.deriv2, file = dd2_file)

  #Remove any extraneous variables
  #rm(data.splines, data.deriv1, data.deriv2, spline.values, getValues)
  #Garbage cleanup
  gc()
}
cat("...end\n")
